# similaridade

Verificador de Similaridade de Textos com Hash e AVL (Estrutura de Dados II).

## Estrutura

Todos os fontes ficam em `Projeto/`, sem pacotes, para compilar com `javac *.java`.

| Classe | Responsabilidade |
|---|---|
| `Main` | Lê argumentos, carrega documentos, compara pares, monta a AVL e gera a saída/`resultado.txt` |
| `Documento` | Lê um arquivo, normaliza o texto e conta palavras na sua `HashTable` |
| `HashTable` | Tabela hash manual (endereçamento aberto, sondagem linear, `hashPolinomial` e `hashSDBM`) |
| `ComparadorDeDocumentos` | Similaridade do Cosseno |
| `AVLTree` | AVL com chave = similaridade, lista de `Resultado` por nó e contagem de rotações |
| `ContagemRotacoes` | Registro das rotações retornado pela inserção |
| `Resultado` | Par de documentos + similaridade |
| `Experimentos` | Gera tabelas/CSVs para a análise experimental do relatório |

## Execução (JDK 17+)

```sh
cd Projeto
javac *.java
java Main ./documentos 0.75 lista
java Main ./documentos 0.8 topK 5
java Main ./documentos 0.0 busca doc1.txt doc4.txt
java Main ./documentos 0.5 lista --hash=2   # usa hashSDBM
```

A saída também é gravada em `resultado.txt` no diretório de execução.

## Testes e experimentos

```sh
./testes.sh                     # roda vários cenários válidos e inválidos
java Experimentos ./documentos  # tabelas no terminal + CSVs em ./experimentos/
```
